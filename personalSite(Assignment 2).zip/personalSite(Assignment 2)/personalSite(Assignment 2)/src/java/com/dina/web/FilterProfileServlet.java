/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dina.web;

import com.dina.model.ProfileBean;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 *
 * @author User
 */
@WebServlet(name = "FilterProfileServlet", urlPatterns = {"/FilterProfileServlet"})
public class FilterProfileServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/studentProfiles";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String program = request.getParameter("program");
        List<ProfileBean> profiles = new ArrayList<>();

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            PreparedStatement ps;

            // all prog
            if (program == null || program.isEmpty()) {
                ps = con.prepareStatement("SELECT * FROM profile");
            } 
            // filter by prog
            else {
                ps = con.prepareStatement(
                    "SELECT * FROM profile WHERE program = ?");
                ps.setString(1, program);
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ProfileBean p = new ProfileBean();
                p.setName(rs.getString("name"));
                p.setStudentId(rs.getString("student_id"));
                p.setProgram(rs.getString("program"));
                p.setEmail(rs.getString("email"));
                p.setHobbies(rs.getString("hobbies"));

                profiles.add(p);
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("profiles", profiles);
        request.getRequestDispatcher("viewProfiles.jsp").forward(request, response);
    }
}